#!/usr/bin/env python3
"""Build raw full-context cases from audited public coding-agent trajectories.

This builder replaces the old evidence-card-first dataset for R1.3-style
experiments. It extracts trajectory fields from public Hugging Face datasets and
keeps the complete source row in `source_payload`. It does not create gold
labels, detector outputs, judge outputs, or cropped evidence packs.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import Counter, OrderedDict, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable


DATASETS_SERVER = "https://datasets-server.huggingface.co"
SCHEMA_VERSION = "swe_hallubench_full_context_case.v1"
DATASET_NAME = "open_full_context_trajectory_cases_20260622"
DEFAULT_SOURCE_ORDER = [
    "coderforge_verified_eval",
    "swegym_openhands_sampled",
    "swe_smith_trajectories",
    "nebius_swe_agent",
    "nebius_swerebench_openhands",
]
FORBIDDEN_LABEL_FIELDS = {"gold_label", "label", "judgment", "gold", "gold_units", "gold_evidence", "accepted_label"}


def now_iso() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def stable_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)


def sha256_value(value: Any) -> str:
    return hashlib.sha256(stable_json(value).encode("utf-8")).hexdigest()


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    rows = []
    with path.open(encoding="utf-8") as handle:
        for line in handle:
            if line.strip():
                rows.append(json.loads(line))
    return rows


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")


def write_jsonl(path: Path, rows: Iterable[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")


def api_get(path: str, params: dict[str, Any], timeout: int = 90, attempts: int = 6) -> dict[str, Any]:
    query = urllib.parse.urlencode(params, doseq=True)
    url = f"{DATASETS_SERVER}{path}?{query}"
    last_error = ""
    for attempt in range(1, attempts + 1):
        try:
            request = urllib.request.Request(url, headers={"User-Agent": "swe-hallubench-full-context-builder/1.0"})
            with urllib.request.urlopen(request, timeout=timeout) as response:
                return {
                    "ok": True,
                    "url": url,
                    "status": getattr(response, "status", None),
                    "data": json.loads(response.read().decode("utf-8")),
                }
        except urllib.error.HTTPError as exc:
            last_error = repr(exc)
            if attempt < attempts:
                time.sleep(min(10 * attempt, 60) if exc.code == 429 else 1.5 * attempt)
        except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
            last_error = repr(exc)
            if attempt < attempts:
                time.sleep(1.5 * attempt)
    return {"ok": False, "url": url, "error": last_error}


def hf_rows_url(dataset_id: str, config: str, split: str, offset: int, length: int) -> str:
    return f"{DATASETS_SERVER}/rows?{urllib.parse.urlencode({'dataset': dataset_id, 'config': config, 'split': split, 'offset': offset, 'length': length})}"


def rows_from_response(payload: dict[str, Any]) -> list[tuple[int | None, dict[str, Any]]]:
    rows = []
    for item in payload.get("rows", []) if isinstance(payload, dict) else []:
        if isinstance(item, dict) and isinstance(item.get("row"), dict):
            rows.append((item.get("row_idx"), item["row"]))
    return rows


def is_nonempty(value: Any) -> bool:
    if value is None:
        return False
    if isinstance(value, str):
        return bool(value.strip())
    if isinstance(value, (list, tuple, dict, set)):
        return len(value) > 0
    return True


def try_parse_json(value: Any) -> Any:
    if not isinstance(value, str):
        return value
    text = value.strip()
    if not text or text[0] not in "[{":
        return value
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return value


def normalize_path(path: str) -> str:
    return path.replace("[]", "")


def get_path(value: Any, path: str) -> Any:
    current = value
    for raw_part in normalize_path(path).split("."):
        part = raw_part.strip()
        if not part:
            continue
        if isinstance(current, dict):
            current = current.get(part)
        elif isinstance(current, list):
            extracted = []
            for item in current:
                if isinstance(item, dict) and part in item:
                    extracted.append(item[part])
            current = extracted
        else:
            return None
    return current


def first_value(row: dict[str, Any], paths: Iterable[str]) -> tuple[str, Any]:
    for path in paths:
        value = get_path(row, path)
        if is_nonempty(value):
            return path, value
    return "", None


def collect_raw_fields(row: dict[str, Any], paths: Iterable[str]) -> dict[str, Any]:
    raw = OrderedDict()
    for path in paths:
        value = get_path(row, path)
        if is_nonempty(value):
            raw[path] = value
    return dict(raw)


def parsed_mapping(value: Any) -> dict[str, Any]:
    parsed = try_parse_json(value)
    return parsed if isinstance(parsed, dict) else {}


def infer_instance_id(row: dict[str, Any]) -> str:
    for path in ("instance_id", "ds.instance_id", "target.instance_id"):
        value = get_path(row, path)
        if is_nonempty(value):
            return str(value)
    ds = parsed_mapping(row.get("ds"))
    if is_nonempty(ds.get("instance_id")):
        return str(ds["instance_id"])
    for path in ("trajectory_id", "traj_id", "run_id"):
        value = get_path(row, path)
        if is_nonempty(value):
            return str(value)
    return "unknown_instance"


def infer_task_metadata(row: dict[str, Any]) -> dict[str, Any]:
    ds = parsed_mapping(row.get("ds"))
    target = parsed_mapping(row.get("target"))
    repo = row.get("repo") or ds.get("repo") or target.get("repo")
    base_commit = row.get("base_commit") or ds.get("base_commit") or target.get("base_commit")
    problem_statement = (
        row.get("problem_statement")
        or ds.get("problem_statement")
        or target.get("problem_statement")
        or row.get("instruction")
        or row.get("input")
        or infer_instance_id(row)
    )
    return {
        "instance_id": infer_instance_id(row),
        "repo": repo,
        "base_commit": base_commit,
        "problem_statement": problem_statement,
    }


def message_count(raw_trajectory: Any) -> int:
    parsed = try_parse_json(raw_trajectory)
    if isinstance(parsed, list):
        return len(parsed)
    if isinstance(parsed, dict):
        for key in ("messages", "trajectory", "steps"):
            value = parsed.get(key)
            if isinstance(value, list):
                return len(value)
    if isinstance(raw_trajectory, str):
        return raw_trajectory.count("\n") + 1 if raw_trajectory.strip() else 0
    return 0


def tool_observation_count(raw_trajectory: Any) -> int:
    parsed = try_parse_json(raw_trajectory)
    if isinstance(parsed, list):
        return sum(1 for item in parsed if isinstance(item, dict) and str(item.get("role", "")).lower() in {"tool", "observation"})
    if isinstance(raw_trajectory, str):
        lowered = raw_trajectory.lower()
        return lowered.count("observation") + lowered.count("tool")
    return 0


def infer_run_id(row: dict[str, Any]) -> str:
    for path in ("run_id", "trajectory_id", "traj_id"):
        value = get_path(row, path)
        if is_nonempty(value):
            return str(value)
    return infer_instance_id(row)


def infer_acting_model(row: dict[str, Any]) -> str:
    for path in ("model", "model_name", "exp_name", "selected_models"):
        value = get_path(row, path)
        if is_nonempty(value):
            if isinstance(value, list):
                return ",".join(map(str, value[:3]))
            return str(value)
    return "unknown"


def build_full_context_record(
    source: dict[str, Any],
    row: dict[str, Any],
    *,
    config: str,
    split: str,
    row_index: int | None,
) -> dict[str, Any]:
    field_groups = source.get("field_groups", {})
    trajectory_path, raw_trajectory = first_value(row, field_groups.get("trajectory_messages", []))
    patch_path, patch_text = first_value(row, field_groups.get("patch", []))
    task_metadata = infer_task_metadata(row)
    instance_id = task_metadata["instance_id"]
    run_id = infer_run_id(row)
    source_id = str(source.get("source_id") or "unknown_source")
    agent_system = str(source.get("agent_system_id") or source.get("agent_framework") or "unknown_agent")
    case_key = f"{source_id}:{config}:{split}:{row_index}:{instance_id}:{run_id}"
    execution_raw = collect_raw_fields(row, field_groups.get("test_or_reward", []))
    observation_raw = collect_raw_fields(row, field_groups.get("tool_observations", []))
    metadata_raw = collect_raw_fields(row, field_groups.get("agent_metadata", []))
    raw_traj_is_present = is_nonempty(raw_trajectory)
    patch_is_present = is_nonempty(patch_text)
    execution_is_present = bool(execution_raw)
    observation_count = tool_observation_count(raw_trajectory)
    has_repo_pointer = bool(task_metadata.get("repo") or task_metadata.get("base_commit"))
    record = {
        "schema_version": SCHEMA_VERSION,
        "case_id": f"{case_key}:{sha256_value(row)[:12]}",
        "instance_id": instance_id,
        "source": {
            "source_id": source_id,
            "dataset_id": source.get("dataset_id"),
            "hf_url": source.get("hf_url"),
            "agent_system_id": agent_system,
            "agent_framework": source.get("agent_framework"),
            "task_source": source.get("task_source"),
            "recommended_role": source.get("recommended_role"),
        },
        "source_locator": {
            "config": config,
            "split": split,
            "hf_row_index": row_index,
            "hf_rows_url": hf_rows_url(str(source.get("dataset_id") or ""), config, split, int(row_index or 0), 1),
            "source_row_sha256": sha256_value(row),
        },
        "sample_unit": {
            "unit_type": "full_context_case",
            "instance_id": instance_id,
            "agent_system": agent_system,
            "acting_model": infer_acting_model(row),
            "run_id": run_id,
        },
        "task_metadata": task_metadata,
        "full_trajectory": {
            "source_field": trajectory_path,
            "raw": raw_trajectory,
            "message_count": message_count(raw_trajectory),
            "tool_observation_count": observation_count,
            "format_note": "raw public dataset trajectory field; no evidence-card cropping",
        },
        "repo_context": {
            "repo": task_metadata.get("repo"),
            "base_commit": task_metadata.get("base_commit"),
            "snapshot_path": "",
            "recovery_note": "public dataset supplies repo/base metadata only; repo snapshot is not materialized by this builder",
        },
        "final_patch": {
            "source_field": patch_path,
            "chars": len(str(patch_text or "")),
            "text": patch_text,
        },
        "execution_artifacts": {
            "available": "partial" if execution_is_present else "no",
            "raw": execution_raw,
        },
        "structured_signals": {
            "nonempty_patch": patch_is_present,
            "patch_chars": len(str(patch_text or "")),
            "resolved": row.get("resolved") if "resolved" in row else (execution_raw.get("resolved") if isinstance(execution_raw, dict) else None),
            "reward": row.get("reward"),
            "exit_status": row.get("exit_status"),
            "execution_artifacts_available": "partial" if execution_is_present else "no",
            "tool_observation_count": observation_count,
            "message_count": message_count(raw_trajectory),
        },
        "recoverability": {
            "full_trajectory_available": "yes" if raw_traj_is_present else "no",
            "repo_snapshot_recoverable": "partial" if has_repo_pointer else "no",
            "base_commit_available": "yes" if task_metadata.get("base_commit") else "no",
            "final_patch_available": "yes" if patch_is_present else "no",
            "execution_artifacts_available": "partial" if execution_is_present else "no",
            "tool_observations_available": "full" if observation_count or observation_raw else "no",
            "judge_can_inspect_repo": "limited" if has_repo_pointer or patch_is_present else "no",
        },
        "label_policy": {
            "human_gold": "absent",
            "detector_output": "absent",
            "judge_output": "absent",
            "outcome_fields": "judge_context_only_not_gold",
            "metric_source": "future_judge_adjudicated_detector_correctness",
        },
        "source_payload": row,
    }
    if metadata_raw:
        record["agent_metadata"] = metadata_raw
    return record


def identity_key(record: dict[str, Any]) -> str:
    return f"{(record.get('source') or {}).get('source_id')}:{record.get('instance_id')}"


def assign_grouped_splits(
    records: list[dict[str, Any]],
    *,
    train_ratio: float = 1.5,
    dev_ratio: float = 0.5,
    test_ratio: float = 1.0,
) -> list[dict[str, Any]]:
    by_source: OrderedDict[str, OrderedDict[str, list[dict[str, Any]]]] = OrderedDict()
    for record in records:
        source_id = str((record.get("source") or {}).get("source_id") or "unknown")
        by_source.setdefault(source_id, OrderedDict()).setdefault(identity_key(record), []).append(record)

    assigned: list[dict[str, Any]] = []
    total_ratio = train_ratio + dev_ratio + test_ratio
    for source_id, groups in by_source.items():
        group_items = list(groups.values())
        total_groups = len(group_items)
        train_target = min(total_groups, int(round(total_groups * train_ratio / total_ratio)))
        dev_target = min(max(total_groups - train_target, 0), int(round(total_groups * dev_ratio / total_ratio)))
        for index, rows in enumerate(group_items):
            if index < train_target:
                split = "train"
            elif index < train_target + dev_target:
                split = "dev"
            else:
                split = "test"
            for row in rows:
                item = dict(row)
                item["split"] = split
                item["split_assignment"] = {
                    "policy": "grouped_by_source_instance_ratio",
                    "source_id": source_id,
                    "identity_key_sha256": hashlib.sha256(identity_key(row).encode("utf-8")).hexdigest(),
                    "ratios": {"train": train_ratio, "dev": dev_ratio, "test": test_ratio},
                }
                assigned.append(item)
    return assigned


def quality_report(records: list[dict[str, Any]]) -> dict[str, Any]:
    schema_valid = sum(row.get("schema_version") == SCHEMA_VERSION for row in records)
    full_context_units = sum((row.get("sample_unit") or {}).get("unit_type") == "full_context_case" for row in records)
    source_payload_present = sum("source_payload" in row and isinstance(row.get("source_payload"), dict) for row in records)
    forbidden_label_rows = sum(any(key in row for key in FORBIDDEN_LABEL_FIELDS) for row in records)
    by_instance: dict[str, set[str]] = defaultdict(set)
    for row in records:
        by_instance[str(row.get("instance_id"))].add(str(row.get("split", "")))
    leakage = {instance_id: sorted(splits) for instance_id, splits in by_instance.items() if len(splits) > 1}
    recoverability = Counter((row.get("recoverability") or {}).get("full_trajectory_available") for row in records)
    by_source = Counter((row.get("source") or {}).get("source_id") for row in records)
    by_split = Counter(row.get("split") for row in records)
    return {
        "dataset_name": DATASET_NAME,
        "schema_version": SCHEMA_VERSION,
        "records": len(records),
        "schema_valid": schema_valid,
        "full_context_unit": full_context_units,
        "source_payload_present": source_payload_present,
        "forbidden_label_field_rows": forbidden_label_rows,
        "cross_split_instance_leakage": leakage,
        "full_trajectory_recoverability": dict(recoverability),
        "counts_by_source": dict(by_source),
        "counts_by_split": dict(by_split),
        "quality_gate_pass": (
            len(records) > 0
            and schema_valid == len(records)
            and full_context_units == len(records)
            and source_payload_present == len(records)
            and forbidden_label_rows == 0
            and not leakage
        ),
    }


def load_source_catalog(path: Path) -> list[dict[str, Any]]:
    rows = read_jsonl(path)
    by_id = {row.get("source_id"): row for row in rows}
    ordered = [by_id[source_id] for source_id in DEFAULT_SOURCE_ORDER if source_id in by_id]
    ordered.extend(row for row in rows if row.get("source_id") not in DEFAULT_SOURCE_ORDER)
    return ordered


def split_keys_from_audit(source_audit_path: Path | None) -> dict[str, list[tuple[str, str]]]:
    if not source_audit_path or not source_audit_path.exists():
        return {}
    audit = read_json(source_audit_path)
    result: dict[str, list[tuple[str, str]]] = {}
    for item in audit:
        source_id = ((item.get("source") or {}).get("source_id")) or item.get("source_id")
        splits = (((item.get("api") or {}).get("splits") or {}).get("data") or {}).get("splits") or []
        for split in splits:
            config_name = split.get("config")
            split_name = split.get("split")
            if source_id and config_name and split_name:
                result.setdefault(source_id, []).append((str(config_name), str(split_name)))
    return result


def parse_source_limits(items: list[str]) -> dict[str, int]:
    limits = {}
    for item in items:
        if "=" not in item:
            raise ValueError(f"invalid --source-limit {item!r}; expected source_id=N")
        key, value = item.split("=", 1)
        limits[key.strip()] = int(value)
    return limits


def selected_sources(catalog: list[dict[str, Any]], source_ids: list[str]) -> list[dict[str, Any]]:
    if not source_ids:
        source_ids = DEFAULT_SOURCE_ORDER
    wanted = set(source_ids)
    return [source for source in catalog if source.get("source_id") in wanted]


def build_records_from_hf(
    sources: list[dict[str, Any]],
    split_keys: dict[str, list[tuple[str, str]]],
    *,
    per_source_limit: int,
    source_limits: dict[str, int],
    page_size: int,
    require_patch: bool,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    records: list[dict[str, Any]] = []
    sampling_log: list[dict[str, Any]] = []
    for source in sources:
        source_id = str(source.get("source_id"))
        dataset_id = str(source.get("dataset_id"))
        target = source_limits.get(source_id, per_source_limit)
        accepted_before = len(records)
        keys = split_keys.get(source_id) or [("default", "train")]
        for config, split in keys:
            offset = 0
            while len(records) - accepted_before < target:
                length = min(page_size, target - (len(records) - accepted_before))
                response = api_get(
                    "/rows",
                    {"dataset": dataset_id, "config": config, "split": split, "offset": offset, "length": length},
                )
                log_row = {
                    "source_id": source_id,
                    "config": config,
                    "split": split,
                    "offset": offset,
                    "length": length,
                    "ok": response.get("ok"),
                    "error": response.get("error"),
                    "accepted_before": len(records),
                }
                if not response.get("ok"):
                    sampling_log.append(log_row)
                    break
                rows = rows_from_response(response["data"])
                log_row["returned_rows"] = len(rows)
                if not rows:
                    sampling_log.append(log_row)
                    break
                for row_index, row in rows:
                    record = build_full_context_record(source, row, config=config, split=split, row_index=row_index)
                    if record["recoverability"]["full_trajectory_available"] != "yes":
                        continue
                    if require_patch and record["recoverability"]["final_patch_available"] != "yes":
                        continue
                    records.append(record)
                    if len(records) - accepted_before >= target:
                        break
                log_row["accepted_after"] = len(records)
                sampling_log.append(log_row)
                offset += len(rows)
                if len(rows) < length:
                    break
    return records, sampling_log


def records_from_cached_evidence_cards(
    cards: list[dict[str, Any]],
    *,
    source_limits: dict[str, int],
    require_patch: bool,
    source_by_id: dict[str, dict[str, Any]] | None = None,
) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    counts: Counter[str] = Counter()
    source_by_id = source_by_id or {}
    for card in cards:
        source_id = str((card.get("source") or {}).get("source_id") or "")
        if source_limits and counts[source_id] >= source_limits.get(source_id, math.inf):
            continue
        cached_source = dict(source_by_id.get(source_id) or {})
        cached_source.update(card.get("source") or {})
        if not cached_source.get("field_groups") and source_by_id.get(source_id):
            cached_source["field_groups"] = source_by_id[source_id].get("field_groups")
        row = card.get("source_payload")
        if not source_id or not isinstance(row, dict):
            continue
        locator = card.get("source_locator") or {}
        record = build_full_context_record(
            cached_source,
            row,
            config=str(locator.get("config") or "cached"),
            split=str(locator.get("split") or "cached"),
            row_index=locator.get("hf_row_index"),
        )
        if record["recoverability"]["full_trajectory_available"] != "yes":
            continue
        if require_patch and record["recoverability"]["final_patch_available"] != "yes":
            continue
        records.append(record)
        counts[source_id] += 1
    return records


def manifest(records: list[dict[str, Any]], quality: dict[str, Any], sources: list[dict[str, Any]], args: argparse.Namespace) -> dict[str, Any]:
    return {
        "created_at": now_iso(),
        "dataset_name": DATASET_NAME,
        "schema_version": SCHEMA_VERSION,
        "purpose": "Raw public coding-agent trajectory cases for full-context hallucination detector evaluation.",
        "policy": {
            "detector_main_input": "full trajectory + task metadata + patch + execution artifacts",
            "evidence_cards": "not used as detector main input",
            "outcome_fields": "judge context only, never gold labels",
            "labels_generated": False,
            "source_payload_preserved": True,
        },
        "args": {
            "per_source_limit": args.per_source_limit,
            "source_ids": args.source_id,
            "require_patch": args.require_patch,
            "page_size": args.page_size,
        },
        "quality": quality,
        "sources": [
            {
                "source_id": source.get("source_id"),
                "dataset_id": source.get("dataset_id"),
                "agent_system_id": source.get("agent_system_id"),
                "recommended_role": source.get("recommended_role"),
            }
            for source in sources
        ],
    }


def run_build(args: argparse.Namespace) -> dict[str, Any]:
    catalog = load_source_catalog(args.source_catalog)
    sources = selected_sources(catalog, args.source_id)
    split_keys = split_keys_from_audit(args.source_audit)
    source_limits = parse_source_limits(args.source_limit)
    if not source_limits:
        source_limits = {str(source.get("source_id")): args.per_source_limit for source in sources}
    if args.source_cards_jsonl:
        source_by_id = {str(source.get("source_id")): source for source in catalog}
        records = records_from_cached_evidence_cards(
            read_jsonl(args.source_cards_jsonl),
            source_limits=source_limits,
            require_patch=args.require_patch,
            source_by_id=source_by_id,
        )
        sampling_log = [
            {
                "mode": "cached_source_payload",
                "source_cards_jsonl": str(args.source_cards_jsonl),
                "records_extracted": len(records),
            }
        ]
    else:
        records, sampling_log = build_records_from_hf(
            sources,
            split_keys,
            per_source_limit=args.per_source_limit,
            source_limits=source_limits,
            page_size=args.page_size,
            require_patch=args.require_patch,
        )
    records = assign_grouped_splits(records, train_ratio=args.train_ratio, dev_ratio=args.dev_ratio, test_ratio=args.test_ratio)
    quality = quality_report(records)
    output = args.output_dir
    output.mkdir(parents=True, exist_ok=True)
    write_jsonl(output / "full_context_cases.jsonl", records)
    for split in ("train", "dev", "test"):
        write_jsonl(output / f"full_context_cases_{split}.jsonl", [row for row in records if row.get("split") == split])
    write_json(output / "quality_report.json", quality)
    write_jsonl(output / "sampling_log.jsonl", sampling_log)
    result = manifest(records, quality, sources, args)
    write_json(output / "manifest.json", result)
    return result


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-catalog", type=Path, default=Path("data/open_swe_agent_full_trace_cards_20260617/source_catalog/source_catalog.jsonl"))
    parser.add_argument("--source-audit", type=Path, default=Path("data/open_swe_agent_full_trace_cards_20260617/source_catalog/source_audit.json"))
    parser.add_argument("--source-cards-jsonl", type=Path, help="Re-extract raw trajectory cases from cached evidence-card source_payload rows.")
    parser.add_argument("--output-dir", type=Path, default=Path("data") / DATASET_NAME)
    parser.add_argument("--source-id", action="append", default=[])
    parser.add_argument("--source-limit", action="append", default=[], help="Override a source quota, e.g. coderforge_verified_eval=20.")
    parser.add_argument("--per-source-limit", type=int, default=30)
    parser.add_argument("--page-size", type=int, default=25)
    parser.add_argument("--train-ratio", type=float, default=1.5)
    parser.add_argument("--dev-ratio", type=float, default=0.5)
    parser.add_argument("--test-ratio", type=float, default=1.0)
    parser.add_argument("--require-patch", action=argparse.BooleanOptionalAction, default=True)
    args = parser.parse_args(argv)
    if args.per_source_limit < 1:
        raise SystemExit("--per-source-limit must be >= 1")
    if args.page_size < 1 or args.page_size > 100:
        raise SystemExit("--page-size must be in [1, 100]")
    if not args.source_catalog.exists():
        raise SystemExit(f"missing source catalog: {args.source_catalog}")
    if args.source_cards_jsonl and not args.source_cards_jsonl.exists():
        raise SystemExit(f"missing --source-cards-jsonl path: {args.source_cards_jsonl}")
    return args


def main(argv: list[str] | None = None) -> int:
    result = run_build(parse_args(argv))
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
