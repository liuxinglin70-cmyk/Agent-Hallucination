#!/usr/bin/env python3
"""Select a reproducible full-context pilot subset without truncating cases."""

from __future__ import annotations

import argparse
import json
from collections import Counter, OrderedDict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

import run_full_context_r1_3_validation as runner


DEFAULT_SPLIT_ORDER = ["test", "dev", "train"]


def now_iso() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")


def write_jsonl(path: Path, rows: Iterable[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")


def source_id(record: dict[str, Any]) -> str:
    source = record.get("source") if isinstance(record.get("source"), dict) else {}
    return str(source.get("source_id") or record.get("source_id") or "unknown_source")


def prompt_stats(record: dict[str, Any], skill: dict[str, Any]) -> dict[str, Any]:
    prompt = runner.render_detector_prompt(record, skill)
    return {
        "detector_prompt_chars": len(prompt),
        "detector_prompt_sha256": runner.sha256_text(prompt),
    }


def summarize_prompt_chars(values: list[int]) -> dict[str, Any]:
    if not values:
        return {"min": None, "max": None, "avg": None}
    values = sorted(values)
    return {
        "min": values[0],
        "max": values[-1],
        "avg": round(sum(values) / len(values), 2),
        "p50": values[len(values) // 2],
        "p90": values[min(len(values) - 1, int(len(values) * 0.9))],
    }


def split_rank(split: str, preferred_splits: list[str]) -> int:
    try:
        return preferred_splits.index(split)
    except ValueError:
        return len(preferred_splits)


def ordered_source_ids(cases: list[dict[str, Any]]) -> list[str]:
    seen: OrderedDict[str, None] = OrderedDict()
    for case in cases:
        seen.setdefault(source_id(case), None)
    return list(seen)


def select_subset(
    cases: list[dict[str, Any]],
    *,
    skill: dict[str, Any],
    per_source: int,
    max_prompt_chars: int,
    preferred_splits: list[str],
    allow_over_cap: bool,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    if per_source < 1:
        raise ValueError("per_source must be >= 1")
    cap_enabled = max_prompt_chars > 0
    source_order = ordered_source_ids(cases)
    annotated: list[dict[str, Any]] = []
    for index, case in enumerate(cases):
        stats = prompt_stats(case, skill)
        annotated.append(
            {
                "index": index,
                "record": case,
                "source_id": source_id(case),
                "case_id": str(case.get("case_id")),
                "instance_id": str(case.get("instance_id")),
                "split": str(case.get("split") or ""),
                "under_prompt_cap": (not cap_enabled) or stats["detector_prompt_chars"] <= max_prompt_chars,
                **stats,
            }
        )

    selected_meta: list[dict[str, Any]] = []
    selected_records: list[dict[str, Any]] = []
    for sid in source_order:
        group = [row for row in annotated if row["source_id"] == sid]
        group.sort(
            key=lambda row: (
                0 if row["under_prompt_cap"] else 1,
                split_rank(row["split"], preferred_splits),
                row["detector_prompt_chars"],
                row["case_id"],
            )
        )
        chosen_for_source = 0
        seen_instances: set[str] = set()
        for row in group:
            if chosen_for_source >= per_source:
                break
            if not row["under_prompt_cap"] and not allow_over_cap:
                continue
            if row["instance_id"] in seen_instances:
                continue
            seen_instances.add(row["instance_id"])
            chosen_for_source += 1
            selected_records.append(row["record"])
            selected_meta.append({key: row[key] for key in (
                "source_id",
                "case_id",
                "instance_id",
                "split",
                "detector_prompt_chars",
                "detector_prompt_sha256",
                "under_prompt_cap",
            )})

    selected_prompt_chars = [row["detector_prompt_chars"] for row in selected_meta]
    all_prompt_chars = [row["detector_prompt_chars"] for row in annotated]
    audit = {
        "created_at": now_iso(),
        "input_count": len(cases),
        "selected_count": len(selected_records),
        "per_source_target": per_source,
        "max_prompt_chars": max_prompt_chars,
        "allow_over_cap": allow_over_cap,
        "preferred_splits": preferred_splits,
        "source_order": source_order,
        "counts_by_source": dict(sorted(Counter(row["source_id"] for row in selected_meta).items())),
        "counts_by_split": dict(sorted(Counter(row["split"] for row in selected_meta).items())),
        "prompt_chars": {
            "selected": summarize_prompt_chars(selected_prompt_chars),
            "all_input": summarize_prompt_chars(all_prompt_chars),
            "selected_over_cap_count": sum(not row["under_prompt_cap"] for row in selected_meta),
        },
        "quality": runner.dataset_quality(selected_records),
        "selection_policy": {
            "unit": "full_context_case",
            "trajectory_handling": "complete_trajectory_retained_no_truncation",
            "label_policy": "no_gold_or_outcome_labels_used_for_selection",
            "cost_control": "select_cases_by_prompt_size_before_llm_calls; reuse raw-call cache during execution",
        },
        "selected_cases": selected_meta,
    }
    return selected_records, audit


def run_selection(args: argparse.Namespace) -> dict[str, Any]:
    cases = read_jsonl(args.cases_jsonl)
    skill = runner.load_skill(args.skill_path)
    selected, audit = select_subset(
        cases,
        skill=skill,
        per_source=args.per_source,
        max_prompt_chars=args.max_prompt_chars,
        preferred_splits=args.split,
        allow_over_cap=args.allow_over_cap,
    )
    audit["paths"] = {
        "input_cases": str(args.cases_jsonl),
        "output_jsonl": str(args.output_jsonl),
        "manifest_json": str(args.manifest_json),
        "skill_path": str(args.skill_path),
    }
    write_jsonl(args.output_jsonl, selected)
    write_json(args.manifest_json, audit)
    return audit


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cases-jsonl", type=Path, required=True)
    parser.add_argument("--output-jsonl", type=Path, required=True)
    parser.add_argument("--manifest-json", type=Path, required=True)
    parser.add_argument("--skill-path", type=Path, default=Path("outputs") / "gold_free_r1_1_coderforge_50" / "skill_r1.json")
    parser.add_argument("--per-source", type=int, default=5)
    parser.add_argument("--max-prompt-chars", type=int, default=350000)
    parser.add_argument("--split", action="append", default=None, help="Preferred split order. Repeat for test/dev/train.")
    parser.add_argument("--allow-over-cap", action=argparse.BooleanOptionalAction, default=False)
    args = parser.parse_args(argv)
    if args.split is None:
        args.split = list(DEFAULT_SPLIT_ORDER)
    if not args.cases_jsonl.exists():
        raise SystemExit(f"missing --cases-jsonl path: {args.cases_jsonl}")
    if args.per_source < 1:
        raise SystemExit("--per-source must be >= 1")
    if args.max_prompt_chars < 0:
        raise SystemExit("--max-prompt-chars must be >= 0")
    return args


def main(argv: list[str] | None = None) -> int:
    result = run_selection(parse_args(argv))
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
