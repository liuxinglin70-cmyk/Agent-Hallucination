import json
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))


def sample_source():
    return {
        "source_id": "coderforge_verified_eval",
        "dataset_id": "togethercomputer/CoderForge-Preview-32B-SWE-Bench-Verified-Evaluation-trajectories",
        "agent_system_id": "openhands_coderforge",
        "agent_framework": "OpenHands/CoderForge",
        "task_source": "SWE-bench Verified",
        "recommended_role": "external_verified_validation",
        "field_groups": {
            "task_identity": ["problem_statement", "run_id", "trajectory_id", "ds"],
            "trajectory_messages": ["messages", "agent_log"],
            "tool_observations": ["messages", "agent_log", "test_output"],
            "patch": ["output_patch"],
            "test_or_reward": ["reward", "test_output"],
            "agent_metadata": ["exp_name", "image", "run_id"],
        },
    }


def sample_row(instance_id="astropy__astropy-12907", run_id="1"):
    messages = [
        {"role": "system", "content": "You are OpenHands."},
        {"role": "user", "content": "Fix the nested model separability bug."},
        {
            "role": "assistant",
            "content": "I fixed the bug and all tests pass.",
            "tool_calls": [{"id": "call-1", "function": {"name": "bash", "arguments": "pytest"}}],
        },
        {"role": "tool", "content": "1 failed, 14 passed"},
    ]
    return {
        "trajectory_id": f"{instance_id}_run{run_id}",
        "run_id": run_id,
        "problem_statement": "Nested CompoundModels should keep independent outputs separable.",
        "messages": json.dumps(messages),
        "agent_log": "assistant claimed all tests pass after pytest output showed a failure",
        "output_patch": "diff --git a/astropy/modeling/separable.py b/astropy/modeling/separable.py\n+fix\n",
        "test_output": "FAILED astropy/modeling/tests/test_separable.py::test_nested",
        "reward": 0.0,
        "exp_name": "swebench-python-qwen3",
        "image": "sweb.eval.x86_64.astropy__astropy-12907",
        "ds": json.dumps(
            {
                "repo": "astropy/astropy",
                "instance_id": instance_id,
                "base_commit": "d16bfe05a744909de4b27f5875fe0d4ed41ce607",
            }
        ),
    }


class OpenFullContextTrajectoryDatasetTests(unittest.TestCase):
    def test_source_row_becomes_full_context_case_without_evidence_card_labels(self):
        import build_open_full_context_trajectory_dataset as mod

        row = sample_row()
        record = mod.build_full_context_record(
            sample_source(),
            row,
            config="trajectory",
            split="train",
            row_index=7,
        )

        self.assertEqual(record["schema_version"], "swe_hallubench_full_context_case.v1")
        self.assertEqual(record["sample_unit"]["unit_type"], "full_context_case")
        self.assertEqual(record["sample_unit"]["agent_system"], "openhands_coderforge")
        self.assertEqual(record["sample_unit"]["run_id"], "1")
        self.assertEqual(record["task_metadata"]["repo"], "astropy/astropy")
        self.assertEqual(record["task_metadata"]["base_commit"], "d16bfe05a744909de4b27f5875fe0d4ed41ce607")
        self.assertEqual(record["task_metadata"]["problem_statement"], row["problem_statement"])
        self.assertEqual(record["source_payload"], row)
        self.assertEqual(record["full_trajectory"]["raw"], row["messages"])
        self.assertEqual(record["full_trajectory"]["message_count"], 4)
        self.assertEqual(record["final_patch"]["text"], row["output_patch"])
        self.assertEqual(record["execution_artifacts"]["raw"]["test_output"], row["test_output"])
        self.assertEqual(record["label_policy"]["outcome_fields"], "judge_context_only_not_gold")
        self.assertNotIn("evidence_pack", record)
        self.assertNotIn("gold_label", record)

    def test_recoverability_records_public_dataset_limits(self):
        import build_open_full_context_trajectory_dataset as mod

        record = mod.build_full_context_record(
            sample_source(),
            sample_row(),
            config="trajectory",
            split="train",
            row_index=0,
        )

        self.assertEqual(record["recoverability"]["full_trajectory_available"], "yes")
        self.assertEqual(record["recoverability"]["repo_snapshot_recoverable"], "partial")
        self.assertEqual(record["recoverability"]["base_commit_available"], "yes")
        self.assertEqual(record["recoverability"]["final_patch_available"], "yes")
        self.assertEqual(record["recoverability"]["execution_artifacts_available"], "partial")
        self.assertEqual(record["recoverability"]["tool_observations_available"], "full")
        self.assertEqual(record["recoverability"]["judge_can_inspect_repo"], "limited")

    def test_grouped_splits_do_not_split_same_instance_across_train_dev_test(self):
        import build_open_full_context_trajectory_dataset as mod

        records = [
            mod.build_full_context_record(sample_source(), sample_row("same", "1"), config="trajectory", split="train", row_index=0),
            mod.build_full_context_record(sample_source(), sample_row("same", "2"), config="trajectory", split="train", row_index=1),
            mod.build_full_context_record(sample_source(), sample_row("other", "1"), config="trajectory", split="train", row_index=2),
        ]

        assigned = mod.assign_grouped_splits(records, train_ratio=1.0, dev_ratio=1.0, test_ratio=1.0)
        by_instance = {}
        for row in assigned:
            by_instance.setdefault(row["instance_id"], set()).add(row["split"])

        self.assertEqual(by_instance["same"], {"train"})
        self.assertEqual(by_instance["other"], {"dev"})

    def test_quality_report_rejects_label_fields_and_split_leakage(self):
        import build_open_full_context_trajectory_dataset as mod

        clean = mod.build_full_context_record(sample_source(), sample_row("clean"), config="trajectory", split="train", row_index=0)
        leaked = dict(clean)
        leaked["case_id"] = leaked["case_id"] + ":copy"
        leaked["split"] = "test"
        labeled = dict(clean)
        labeled["case_id"] = labeled["case_id"] + ":label"
        labeled["instance_id"] = "labeled"
        labeled["gold_label"] = "positive"

        report = mod.quality_report([clean, leaked, labeled])

        self.assertEqual(report["records"], 3)
        self.assertEqual(report["forbidden_label_field_rows"], 1)
        self.assertIn("clean", report["cross_split_instance_leakage"])
        self.assertFalse(report["quality_gate_pass"])

    def test_cached_evidence_card_payload_can_be_reextracted_as_raw_full_context_case(self):
        import build_open_full_context_trajectory_dataset as mod

        card = {
            "source": sample_source(),
            "source_locator": {"config": "trajectory", "split": "train", "hf_row_index": 3},
            "source_payload": sample_row("cached", "1"),
            "hard_evidence_refs": {"patch": [{"path": "output_patch"}]},
            "schema_version": "open_swe_agent_evidence_card.v2",
        }

        records = mod.records_from_cached_evidence_cards([card], source_limits={"coderforge_verified_eval": 10}, require_patch=True)

        self.assertEqual(len(records), 1)
        record = records[0]
        self.assertEqual(record["instance_id"], "cached")
        self.assertEqual(record["source_payload"], card["source_payload"])
        self.assertEqual(record["source_locator"]["hf_row_index"], 3)
        self.assertNotIn("hard_evidence_refs", record)
        self.assertEqual(record["label_policy"]["detector_output"], "absent")


if __name__ == "__main__":
    unittest.main()
