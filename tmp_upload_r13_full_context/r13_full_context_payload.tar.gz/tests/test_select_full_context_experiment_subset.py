import json
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))


def make_case(source_id, case_id, split, instance_id, payload_chars):
    return {
        "schema_version": "swe_hallubench_full_context_case.v1",
        "case_id": case_id,
        "instance_id": instance_id,
        "split": split,
        "source": {"source_id": source_id},
        "sample_unit": {
            "unit_type": "full_context_case",
            "instance_id": instance_id,
            "agent_system": "openhands",
            "acting_model": "qwen",
            "run_id": case_id,
        },
        "task_metadata": {"problem_statement": "Fix a bug"},
        "full_trajectory": {"raw": "x" * payload_chars, "message_count": 3},
        "repo_context": {"repo": "example/repo", "base_commit": "abc"},
        "final_patch": {"text": "diff --git a/a.py b/a.py\n+x\n"},
        "execution_artifacts": {"available": "partial", "raw": {"test_output": "1 failed"}},
        "structured_signals": {"resolved": False},
        "recoverability": {"execution_artifacts_available": "partial"},
        "label_policy": {"outcome_fields": "judge_context_only_not_gold"},
        "source_payload": {"trajectory": "x" * payload_chars},
    }


class SelectFullContextExperimentSubsetTests(unittest.TestCase):
    def test_selects_balanced_preferred_split_cases_under_prompt_cap_without_mutating_cases(self):
        import select_full_context_experiment_subset as mod

        cases = [
            make_case("source_a", "a-test", "test", "a1", 6000),
            make_case("source_a", "a-dev", "dev", "a2", 1000),
            make_case("source_b", "b-test-too-large", "test", "b1", 40000),
            make_case("source_b", "b-dev", "dev", "b2", 1000),
            make_case("source_b", "b-train", "train", "b3", 500),
        ]

        selected, audit = mod.select_subset(
            cases,
            skill={"name": "test-skill"},
            per_source=1,
            max_prompt_chars=20000,
            preferred_splits=["test", "dev", "train"],
            allow_over_cap=False,
        )

        self.assertEqual([row["case_id"] for row in selected], ["a-test", "b-dev"])
        self.assertEqual(audit["selected_count"], 2)
        self.assertEqual(audit["counts_by_source"], {"source_a": 1, "source_b": 1})
        self.assertEqual(audit["counts_by_split"], {"dev": 1, "test": 1})
        self.assertEqual(audit["selection_policy"]["trajectory_handling"], "complete_trajectory_retained_no_truncation")
        self.assertNotIn("detector_prompt_chars", selected[0])
        self.assertTrue(all(row["under_prompt_cap"] for row in audit["selected_cases"]))

    def test_cli_writes_subset_and_manifest(self):
        import select_full_context_experiment_subset as mod

        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            cases_path = tmp_path / "cases.jsonl"
            output_path = tmp_path / "subset.jsonl"
            manifest_path = tmp_path / "manifest.json"
            cases = [
                make_case("source_a", "a-test", "test", "a1", 1000),
                make_case("source_b", "b-test", "test", "b1", 1000),
            ]
            cases_path.write_text(
                "\n".join(json.dumps(row, ensure_ascii=False) for row in cases) + "\n",
                encoding="utf-8",
            )

            result = mod.run_selection(
                mod.parse_args(
                    [
                        "--cases-jsonl",
                        str(cases_path),
                        "--output-jsonl",
                        str(output_path),
                        "--manifest-json",
                        str(manifest_path),
                        "--per-source",
                        "1",
                        "--max-prompt-chars",
                        "20000",
                    ]
                )
            )

            written = [json.loads(line) for line in output_path.read_text(encoding="utf-8").splitlines()]
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))

        self.assertEqual(result["selected_count"], 2)
        self.assertEqual(len(written), 2)
        self.assertTrue(manifest["quality"]["quality_gate_pass"])
        self.assertEqual(manifest["input_count"], 2)


if __name__ == "__main__":
    unittest.main()
