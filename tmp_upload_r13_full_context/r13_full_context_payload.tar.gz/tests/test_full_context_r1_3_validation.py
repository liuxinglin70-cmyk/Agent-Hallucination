import json
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))


def write_json(path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def make_run_root(tmp_path, run_id="verified_qwen_step30_n3"):
    instance_id = "django__django-10097"
    run_root = tmp_path / run_id
    instance_dir = run_root / "instances" / instance_id
    traj_path = instance_dir / "miniswe_output" / instance_id / f"{instance_id}.traj.json"
    diff_path = instance_dir / "final_worktree_diff.patch"
    report_path = instance_dir / "report.json"
    metadata_path = run_root / "metadata" / f"{instance_id}.json"

    write_json(
        traj_path,
        {
            "trajectory_format": "mini-swe-agent-1.1",
            "info": {"exit_status": "LimitsExceeded", "submission": ""},
            "messages": [
                {"role": "system", "content": "system"},
                {"role": "user", "content": "Fix URL validation"},
                {
                    "role": "assistant",
                    "content": "The URL validator is fixed and ready.",
                    "reasoning_content": "The target tests should pass after the regex update.",
                },
                {"role": "tool", "content": "<returncode>0</returncode><output>target ok</output>"},
            ],
        },
    )
    diff_path.parent.mkdir(parents=True, exist_ok=True)
    diff_path.write_text("diff --git a/django/core/validators.py b/django/core/validators.py\n+new\n", encoding="utf-8")
    write_json(
        report_path,
        {
            "evaluation": {
                instance_id: {
                    "patch_successfully_applied": True,
                    "resolved": False,
                    "tests_status": {
                        "FAIL_TO_PASS": {"success": ["target"], "failure": []},
                        "PASS_TO_PASS": {"success": [], "failure": ["regression"]},
                    },
                }
            },
            "official_semantics": {"docker_isolation": False},
        },
    )
    write_json(
        metadata_path,
        {
            "instance_id": instance_id,
            "repo": "django/django",
            "base_commit": "abc123",
            "problem_statement": "Fix URL validation",
        },
    )
    write_json(
        run_root / "pilot20_summary.json",
        {
            "run_id": run_id,
            "model": "openai/Qwen3.5-397B-A17B",
            "results": [
                {
                    "instance_id": instance_id,
                    "repo": "django/django",
                    "base_commit": "abc123",
                    "model": "openai/Qwen3.5-397B-A17B",
                    "traj_path": str(traj_path),
                    "final_worktree_diff_path": str(diff_path),
                    "messages_count": 4,
                    "api_calls": 2,
                    "exit_status": "LimitsExceeded",
                    "runtime_seconds": 12.5,
                }
            ],
        },
    )
    return run_root, instance_id


class FullContextR13ValidationTests(unittest.TestCase):
    def test_build_full_context_cases_preserves_real_unit_and_recoverability(self):
        import run_full_context_r1_3_validation as mod

        with tempfile.TemporaryDirectory() as tmp:
            run_root, instance_id = make_run_root(Path(tmp))

            records = mod.build_full_context_cases([run_root], max_cases=10)

        self.assertEqual(len(records), 1)
        record = records[0]
        self.assertEqual(record["schema_version"], "swe_hallubench_full_context_case.v1")
        self.assertEqual(record["sample_unit"]["unit_type"], "full_context_case")
        self.assertEqual(record["sample_unit"]["instance_id"], instance_id)
        self.assertEqual(record["sample_unit"]["agent_system"], "mini-swe-agent")
        self.assertNotIn("evidence_pack", record)
        self.assertNotIn("gold_label", record)
        self.assertEqual(record["recoverability"]["full_trajectory_available"], "yes")
        self.assertEqual(record["recoverability"]["execution_artifacts_available"], "full")
        self.assertEqual(record["structured_signals"]["target_tests_passed"], True)
        self.assertEqual(record["structured_signals"]["regression_tests_passed"], False)
        self.assertEqual(record["label_policy"]["outcome_fields"], "judge_context_only_not_gold")

    def test_split_assignment_groups_duplicate_instances_to_prevent_leakage(self):
        import run_full_context_r1_3_validation as mod

        records = [
            {"case_id": "run-a", "instance_id": "same", "source_run_id": "a"},
            {"case_id": "run-b", "instance_id": "same", "source_run_id": "b"},
            {"case_id": "run-c", "instance_id": "other", "source_run_id": "c"},
        ]

        assigned = mod.assign_nonoverlap_splits(records, train_groups=1, dev_groups=1)
        by_instance = {}
        for row in assigned:
            by_instance.setdefault(row["instance_id"], set()).add(row["split"])

        self.assertEqual(by_instance["same"], {"train"})
        self.assertEqual(by_instance["other"], {"dev"})

    def test_compute_judge_adjudicated_metrics_uses_judge_tp_fp_fn_tn_not_outcome(self):
        import run_full_context_r1_3_validation as mod

        judge_rows = [
            {
                "case_id": "tp",
                "judge_status": "accepted",
                "case_has_hallucination": True,
                "detector_has_hallucination": True,
                "matched_units": [{"localization_quality": "correct", "category_quality": "correct"}],
                "false_positives": [],
                "false_negatives": [],
            },
            {
                "case_id": "fp",
                "judge_status": "accepted",
                "case_has_hallucination": False,
                "detector_has_hallucination": True,
                "matched_units": [],
                "false_positives": [{"unsupported_unit": "overclaim"}],
                "false_negatives": [],
            },
            {
                "case_id": "fn",
                "judge_status": "accepted",
                "case_has_hallucination": True,
                "detector_has_hallucination": False,
                "matched_units": [],
                "false_positives": [],
                "false_negatives": [{"unsupported_unit": "missed"}],
            },
            {
                "case_id": "tn",
                "judge_status": "accepted",
                "case_has_hallucination": False,
                "detector_has_hallucination": False,
                "matched_units": [],
                "false_positives": [],
                "false_negatives": [],
            },
            {
                "case_id": "uncertain",
                "judge_status": "uncertain",
                "case_has_hallucination": True,
                "detector_has_hallucination": True,
            },
        ]

        metrics = mod.compute_judge_adjudicated_metrics(judge_rows)

        self.assertEqual(metrics["denominator"], 4)
        self.assertEqual(metrics["tp"], 1)
        self.assertEqual(metrics["fp"], 1)
        self.assertEqual(metrics["fn"], 1)
        self.assertEqual(metrics["tn"], 1)
        self.assertAlmostEqual(metrics["precision"], 0.5)
        self.assertAlmostEqual(metrics["recall"], 0.5)
        self.assertAlmostEqual(metrics["f1"], 0.5)
        self.assertEqual(metrics["unit_level"]["tp"], 1)
        self.assertEqual(metrics["unit_level"]["fp"], 1)
        self.assertEqual(metrics["unit_level"]["fn"], 1)
        self.assertEqual(metrics["localization_accuracy"], 1.0)
        self.assertEqual(metrics["label_source"], "judge_adjudicated_detector_correctness")

    def test_detector_prompt_uses_full_context_not_precropped_evidence_pack(self):
        import run_full_context_r1_3_validation as mod

        record = {
            "case_id": "case-a",
            "sample_unit": {"unit_type": "full_context_case"},
            "task_metadata": {"problem_statement": "Fix bug"},
            "full_trajectory": {"messages": [{"role": "assistant", "content": "fixed"}]},
            "repo_context": {"files": {"a.py": "print('x')"}},
            "final_patch": {"text": "diff --git a/a.py b/a.py\n+x\n"},
            "execution_artifacts": {"available": "partial"},
            "structured_signals": {"target_tests_passed": True},
        }
        prompt = mod.render_detector_prompt(record, skill={"name": "r1.3"})

        self.assertIn("FULL_CONTEXT_CASE_JSON", prompt)
        self.assertIn("full trajectory", prompt.lower())
        self.assertNotIn("EVIDENCE_PACKS_JSON", prompt)
        self.assertNotIn("pre-cropped evidence card", prompt.lower())

    def test_dry_run_can_load_rebuilt_public_full_context_cases_jsonl(self):
        import run_full_context_r1_3_validation as mod

        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            cases_path = tmp_path / "full_context_cases.jsonl"
            case = {
                "schema_version": "swe_hallubench_full_context_case.v1",
                "case_id": "public:case-1",
                "instance_id": "astropy__astropy-12907",
                "split": "test",
                "source": {"source_id": "coderforge_verified_eval"},
                "sample_unit": {
                    "unit_type": "full_context_case",
                    "instance_id": "astropy__astropy-12907",
                    "agent_system": "openhands_coderforge",
                    "acting_model": "qwen",
                    "run_id": "1",
                },
                "task_metadata": {"problem_statement": "Fix nested separability"},
                "full_trajectory": {"raw": [{"role": "assistant", "content": "fixed"}], "message_count": 1},
                "repo_context": {"repo": "astropy/astropy", "base_commit": "abc"},
                "final_patch": {"text": "diff --git a/a.py b/a.py\n+x\n", "chars": 28},
                "execution_artifacts": {"available": "partial", "raw": {"test_output": "failed"}},
                "structured_signals": {"resolved": False, "execution_artifacts_available": "partial"},
                "recoverability": {
                    "full_trajectory_available": "yes",
                    "repo_snapshot_recoverable": "partial",
                    "base_commit_available": "yes",
                    "final_patch_available": "yes",
                    "execution_artifacts_available": "partial",
                    "tool_observations_available": "full",
                    "judge_can_inspect_repo": "limited",
                },
                "label_policy": {"outcome_fields": "judge_context_only_not_gold"},
                "source_payload": {"messages": [{"role": "assistant", "content": "fixed"}]},
            }
            cases_path.write_text(json.dumps(case, ensure_ascii=False) + "\n", encoding="utf-8")

            args = mod.parse_args(
                [
                    "--project-root",
                    str(tmp_path),
                    "--cases-jsonl",
                    str(cases_path),
                    "--phase",
                    "r1_3_public_cases_test",
                    "--dry-run",
                ]
            )
            result = mod.run_experiment(args)

        self.assertTrue(result["dry_run"])
        self.assertEqual(result["record_count"], 1)
        self.assertEqual(result["quality"]["records"], 1)
        self.assertEqual(result["quality"]["full_context_unit"], 1)
        self.assertEqual(result["quality"]["forbidden_label_field_rows"], 0)
        self.assertIn("FULL_CONTEXT_CASE_JSON", result["prompt_audit"][0]["prompt_preview"])


if __name__ == "__main__":
    unittest.main()
